import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-notfound',
  templateUrl: './notfound.component.html',
  styleUrls: ['./notfound.component.scss']
})
export class NotfoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
