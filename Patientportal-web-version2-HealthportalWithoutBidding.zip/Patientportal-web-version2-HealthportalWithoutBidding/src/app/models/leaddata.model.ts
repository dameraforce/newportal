export class leadDataModel {
    ProviderId : number;
    Fromdate : string;
    ToDate : string;
    Status : string;
    constructor() {
        this.ProviderId = 0;
        this.Fromdate = "";
        this.ToDate = "";
        this.Status = "";
    }
}