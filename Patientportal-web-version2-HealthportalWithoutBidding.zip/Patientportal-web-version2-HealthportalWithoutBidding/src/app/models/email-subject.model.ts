export class EmailSub {
    Registration: string;
    ChangePassword: string;
    ForgotPassword: string;
    CampaignRegistraion: string;
    AppointmentCancellation: string;
    AppointmentReScheduling: string;
    AppointmentBooking: string;
    PatientRequest: string;
    ApproveRequest:string;
    // CreatedOn: any;
    // CreatedBy: string;
    // ModifiedOn: any;
    // ModifiedBy: string;

    constructor() {
        this.Registration = '';
       this.ChangePassword = '';
       this.ForgotPassword = '';
       this.CampaignRegistraion = '';
       this.AppointmentCancellation = '';
       this.AppointmentReScheduling = '';
       this.AppointmentBooking = '';
       this.PatientRequest = '';
       this.ApproveRequest='';
    //    this.CreatedOn = '';
    //    this.CreatedBy = '';
    //    this.ModifiedOn = '';
    //    this.ModifiedBy = '';

    }
}