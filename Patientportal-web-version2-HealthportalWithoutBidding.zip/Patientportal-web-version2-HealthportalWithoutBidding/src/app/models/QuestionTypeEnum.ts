export enum QuestionTypeEnum {
    RADIO = 15,
    DROPDOWN = 27,
    TEXTBOX = 30,
    CHECKBOX = 34
}