export class dateModel{
    FromDate:any;
    ToDate:any;
    IsActive:string;
}
export class GetDateModel{
    FromDate: any;
    ToDate: any;
    ProviderId: any;
    IsRegular: boolean;
    DOB: string;
    session: string;
    currenttime: string;
}
export class verifydates{
    frmdate:any;
    frmmonth:any;
    frmyear:any;
    todate:any;
    tomonth:any;
    toyear:any;
}