
export enum alertType {
    Success,
    Error,
    Warning
}
