export class OrganizationModel {
Id: number;
IsOrganization: boolean;
Date: any;
UserName: string;
}
