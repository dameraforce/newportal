export class LoginModel {
    Name: string;
    PassWord: string;
    constructor() {
        this.Name = '';
        this.PassWord = '';
    }
}
