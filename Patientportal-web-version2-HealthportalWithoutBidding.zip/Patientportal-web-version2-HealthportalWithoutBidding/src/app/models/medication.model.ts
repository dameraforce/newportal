export class MedicationModel {
    Id: number;
    Name: string;
    Description: string;
    IsActive: boolean;
    CreatedOn: string;
    CreatedDate: string;
    CreatedBy: number;
    UpdatedDate: string;
    UpdatedBy: string;
    PersonId: number;
    ModifiedOn: string;
}
