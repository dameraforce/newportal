import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'app-patient-registartion',
    templateUrl: 'patient-registartion.component.html',
    styleUrls: ['patient-registartion.component.scss']
})
export class PatientRegistartionComponent {
constructor() {
}
}
