import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'kiosk',
    templateUrl: 'kiosk.component.html',
    styleUrls: ['kiosk.component.css']
})
export class KioskComponent {

}
