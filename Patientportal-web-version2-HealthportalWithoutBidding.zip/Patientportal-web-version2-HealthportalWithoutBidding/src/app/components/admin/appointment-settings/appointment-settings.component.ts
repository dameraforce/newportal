import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-settings',
  templateUrl: './appointment-settings.component.html',
  styleUrls: ['./appointment-settings.component.scss']
})
export class AppointmentSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
