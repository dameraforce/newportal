import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-athena',
  templateUrl: './athena.component.html',
  styleUrls: ['./athena.component.scss']
})
export class AthenaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
