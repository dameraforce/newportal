import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-formscontrol',
  templateUrl: './formscontrol.component.html',
  styleUrls: ['./formscontrol.component.scss']
})
export class FormscontrolComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
